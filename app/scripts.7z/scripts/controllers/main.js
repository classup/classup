'use strict';

/**
 * @ngdoc function
 * @name classupApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the classupApp
 */
angular.module('classupApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
